
<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "tp";

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "SELECT * FROM techinal WHERE email='$email' AND password='$pass'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    echo "<script>alert('Login successful!'); window.location.href = 'welcome.html';</script>";
} else {
    echo "<script>alert('Invalid email or password!'); window.history.back();</script>";
}
mysqli_close($conn);
?>
