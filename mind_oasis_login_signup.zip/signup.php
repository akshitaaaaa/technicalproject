
<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "tp";

$conn = mysqli_connect($host, $user, $password, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "INSERT INTO techinal (email, password) VALUES ('$email', '$pass')";
if (mysqli_query($conn, $sql)) {
    echo "<script>alert('Sign-up successful!'); window.location.href = 'index.html';</script>";
} else {
    echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.history.back();</script>";
}
mysqli_close($conn);
?>
